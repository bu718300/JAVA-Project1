package lol;

public class tier_distribution_plotVO {
	String tier;
	String rate;
	String acummulation_rate;
	public String getTier() {
		return tier;
	}
	public void setTier(String tier) {
		this.tier = tier;
	}
	public String getRate() {
		return rate;
	}
	public void setRate(String rate) {
		this.rate = rate;
	}
	public String getAcummulation_rate() {
		return acummulation_rate;
	}
	public void setAcummulation_rate(String acummulation_rate) {
		this.acummulation_rate = acummulation_rate;
	}
}
	