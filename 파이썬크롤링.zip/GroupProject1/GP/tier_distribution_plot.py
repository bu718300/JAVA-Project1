from bs4 import BeautifulSoup
from urllib.request import urlopen

response = urlopen('https://www.op.gg/statistics/tier/')
soup = BeautifulSoup(response, 'html.parser')

tier = [] # 티어
rate = [] # 비율
accumulation_rate = [] #누적비율


tier_all = soup.select('td.Tier.Cell') # td.Tier에 해당하는 부분을 찾아 tier 리스트에 집어넣기
for index in range(0, len(tier_all)): # for문을 사용하여 범위를 지정
    tier.append(tier_all[index].text.strip()) # strip을 통해 공백을 제거하여 tier 리스트에 저장함


rate_all = soup.select('td.SummonerCount.Cell') # td.SummonerCount에 해당하는 부분을 찾아 tier 리스트에 집어넣기
for index in range(0, len(rate_all)): # for문을 사용하여 범위를 지정
    term = rate_all[index].text.split() # split을 통해 공백을 기준으로 분리함
    rate.append(term[1]) # 데이터들 중 2번째의 데이터를 골라 rate 리스트에 저장함


accumulation_rate_all = soup.select('td.Aggregate.Cell') # td.Aggregate에 해당하는 부분을 찾아 tier 리스트에 집어넣기
for index in range(0, len(accumulation_rate_all)): # for문을 사용하여 범위를 지정
    term = accumulation_rate_all[index].text.split() # split을 통해 공백을 기준으로 분리함
    accumulation_rate.append(term[1]) # 데이터들 중 2번째의 데이터를 골라 rate 리스트에 저장함

for i in range(27): #콘솔에 크롤링한 데이터를 띄우기
    print("티어: " + tier[i])
    print("비율: " + str(rate[i]))
    print("누적비율: " + str(accumulation_rate[i]))
    print("---------------------------") 

list = [] # 같은번째의 데이터를 한 행에 넣기위해서 list를 생성(데이터 저장을 원활하게 하기 위함)
for i in range(27):
    list.append(tier[i] + "," + str(rate[i]) + "," +str(accumulation_rate[i]))#int데이터는 str로 강제캐스팅
print("리스트: " + str(list)) #리스트를 출력해서 상태확인

f = open("C:/data.txt", "w") # 메모장으로 데이터를 저장할 장소 지정
f.write("tier,rate,accumulation_rate") # DBeaver 컬럼명 일치 시키기
f.write("\n") #줄 바꿈
for i in range(27): # 반복 저장을 위해 for문 사용
    f.write(list[i])
    f.write("\n") # 행을 구분하기 위해 줄바꿈
f.close() # 완료하고 닫기